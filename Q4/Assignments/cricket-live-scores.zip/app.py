
from flask import Flask, render_template
import requests
import xml.etree.ElementTree as ET

app = Flask(__name__)

RSS_URL = "https://static.cricinfo.com/rss/livescores.xml"

def fetch_scores():
    response = requests.get(RSS_URL)
    root = ET.fromstring(response.content)
    matches = []
    for item in root.findall(".//item"):
        matches.append({
            "title": item.findtext("title"),
            "description": item.findtext("description")
        })
    return matches

@app.route("/")
def index():
    matches = fetch_scores()
    return render_template("index.html", matches=matches)

if __name__ == "__main__":
    app.run(debug=True)
