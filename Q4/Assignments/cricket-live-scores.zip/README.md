
# Cricket Live Scores Web App

## Description
A simple Python Flask web app that displays live cricket scores using ESPN Cricinfo RSS feed.

## How to Run
```bash
pip install -r requirements.txt
python app.py
```

Then open http://127.0.0.1:5000 in your browser.

## Data Source
https://static.cricinfo.com/rss/livescores.xml
